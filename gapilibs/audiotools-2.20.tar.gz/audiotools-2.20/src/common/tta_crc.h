#include <stdint.h>

void
tta_crc32(uint8_t byte, uint32_t *checksum);
